globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/f_QMg74s_z0l9ZqiENsis/_buildManifest.js",
    "static/f_QMg74s_z0l9ZqiENsis/_ssgManifest.js",
    "static/f_QMg74s_z0l9ZqiENsis/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3333gs1h_w689.js",
    "static/chunks/3--cpoboqccjl.js",
    "static/chunks/2drjv1ti9t4pg.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/3333gs1h_w689.js",
        "static/chunks/3--cpoboqccjl.js",
        "static/chunks/2drjv1ti9t4pg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/3333gs1h_w689.js",
        "static/chunks/3--cpoboqccjl.js",
        "static/chunks/2drjv1ti9t4pg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/3333gs1h_w689.js",
        "static/chunks/3--cpoboqccjl.js",
        "static/chunks/2drjv1ti9t4pg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
