:HL["/_next/static/chunks/0m4lk93awlr0x.css","style"]
:HL["/_next/static/chunks/3by1xhi8ukbwo.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"f_QMg74s_z0l9ZqiENsis","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
