"""Validate the generated master DB deliverables."""
import sqlite3
import pandas as pd

xlsx = '/home/z/my-project/download/PesticideNext_Master_Database.xlsx'
db   = '/home/z/my-project/download/PesticideNext_Master.sqlite'

print("=" * 70)
print("EXCEL VALIDATION")
print("=" * 70)
xls = pd.ExcelFile(xlsx)
print("Sheets:", xls.sheet_names)
for s in xls.sheet_names:
    df = pd.read_excel(xlsx, sheet_name=s)
    print(f"  {s:20s}  {df.shape}   cols: {list(df.columns)[:6]} ...")

print("\n" + "=" * 70)
print("SQLITE VALIDATION")
print("=" * 70)
conn = sqlite3.connect(db)
tables = pd.read_sql("SELECT name FROM sqlite_master WHERE type='table';", conn)
print("Tables:", tables['name'].tolist())
for t in tables['name']:
    n = pd.read_sql(f"SELECT COUNT(*) AS n FROM {t};", conn)['n'].iloc[0]
    sample = pd.read_sql(f"SELECT * FROM {t} LIMIT 2;", conn)
    print(f"\n--- {t}  ({n:,} rows) ---")
    print("Columns:", list(sample.columns))
    print(sample.to_string(max_cols=6))

print("\n" + "=" * 70)
print("JOIN-CAPABILITY SPOT CHECK")
print("=" * 70)
# Can we join Products -> Recommendations -> MoA_Reference -> Regulatory_Audit?
q = """
SELECT p.registration_no,
       p.trade_name,
       p.active_ingredient,
       p.toxicity_class,
       p.policy_action   AS ext_policy_action,
       r.policy_action   AS audit_policy_action,
       r.risk_tier,
       r.moa_audit_status,
       m.moa_authority,
       m.resistance_risk,
       (SELECT COUNT(*) FROM Recommendations rc
        WHERE rc.registration_no = p.registration_no) AS rec_count
FROM   Products p
LEFT JOIN Regulatory_Audit r ON r.registration_no = p.registration_no
LEFT JOIN MoA_Reference    m ON m.moa_code         = p.moa_code
WHERE  p.is_hhp LIKE '%YES%'
ORDER  BY rec_count DESC
LIMIT  5;
"""
sample_join = pd.read_sql(q, conn)
print(sample_join.to_string())
conn.close()

import os
print("\n" + "=" * 70)
print("FILE SIZES")
print("=" * 70)
print(f"  xlsx   : {os.path.getsize(xlsx)/1024:>8.1f} KB")
print(f"  sqlite : {os.path.getsize(db)/1024:>8.1f} KB")
