"""Quick inspection of the uploaded Excel files to verify schema assumptions."""
import pandas as pd

extract_path = '/home/z/my-project/upload/AgriChem_DAE_Pesticide_Registry_Extracted (1).xlsx'
schema_path = '/home/z/my-project/upload/AgriChem_Clean_Database_Schema_v2 (2).xlsx'

print("=" * 70)
print("EXTRACT FILE:", extract_path.split('/')[-1])
print("=" * 70)
xls = pd.ExcelFile(extract_path)
print("Sheets:", xls.sheet_names)
for s in xls.sheet_names:
    df = pd.read_excel(extract_path, sheet_name=s, nrows=2)
    print(f"\n--- Sheet: {s} ---")
    print("Shape (full):", pd.read_excel(extract_path, sheet_name=s).shape)
    print("Columns:", list(df.columns))

print("\n" + "=" * 70)
print("SCHEMA FILE:", schema_path.split('/')[-1])
print("=" * 70)
xls2 = pd.ExcelFile(schema_path)
print("Sheets:", xls2.sheet_names)
for s in xls2.sheet_names:
    df = pd.read_excel(schema_path, sheet_name=s, nrows=2)
    print(f"\n--- Sheet: {s} ---")
    print("Shape (full):", pd.read_excel(schema_path, sheet_name=s).shape)
    print("Columns:", list(df.columns))
