"""
PesticideNext / AgriChem Pro — Master Database Builder
========================================================

Builds 4 master tables (Products, Recommendations, MoA_Reference, Regulatory_Audit)
from two source files:

  1. AgriChem_DAE_Pesticide_Registry_Extracted.xlsx  (canonical extract — multi-sheet)
  2. AgriChem_Clean_Database_Schema_v2.xlsx          (Schema v2 — MoA_Audit overlay)

Outputs:
  /home/z/my-project/download/PesticideNext_Master_Database.xlsx   (4 tabs)
  /home/z/my-project/download/PesticideNext_Master.sqlite           (4 tables)

Reconciliation rule: Extract-side policy fields (Bangladesh Policy Action,
Policy Risk Tier) override / supplement Schema v2 audit fields, because
the Extract is the more recent canonical source. The MoA_Audit `status`
field is preserved as the audit overlay (same / conflict / unmapped / ...).
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
import pandas as pd

# ------------------------------------------------------------------
# 0. PATHS
# ------------------------------------------------------------------
extract_path = '/home/z/my-project/upload/AgriChem_DAE_Pesticide_Registry_Extracted (1).xlsx'
schema_path  = '/home/z/my-project/upload/AgriChem_Clean_Database_Schema_v2 (2).xlsx'
out_xlsx     = '/home/z/my-project/download/PesticideNext_Master_Database.xlsx'
out_sqlite   = '/home/z/my-project/download/PesticideNext_Master.sqlite'

Path(out_xlsx).parent.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------
# 1. LOAD SOURCE SHEETS
# ------------------------------------------------------------------
print("[1/7] Loading Extract sheets ...")
ext_products = pd.read_excel(extract_path, sheet_name='Products')
ext_recs     = pd.read_excel(extract_path, sheet_name='Recommendations')
ext_moa      = pd.read_excel(extract_path, sheet_name='MoA_Groups')

print("[1/7] Loading Schema v2 MoA_Audit (header on row 5, skip blank col A) ...")
# Schema v2 sheets have a 4-row banner (title + description + blank) above the
# real header row, and column A is always NaN — read with header=4 and usecols.
df_audit = pd.read_excel(schema_path, sheet_name='MoA_Audit', header=4, usecols='B:O')

print(f"   ext.Products     : {ext_products.shape}")
print(f"   ext.Recommendations: {ext_recs.shape}")
print(f"   ext.MoA_Groups   : {ext_moa.shape}")
print(f"   v2.MoA_Audit     : {df_audit.shape}")

# ------------------------------------------------------------------
# 2. STANDARDIZE & CLEAN KEYS
# ------------------------------------------------------------------
print("[2/7] Standardizing registration_no keys ...")
def clean_key(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip()

ext_products['Registration No'] = clean_key(ext_products['Registration No'])
ext_recs['Registration No']    = clean_key(ext_recs['Registration No'])
df_audit['registration_no']    = clean_key(df_audit['registration_no'])

# Drop rows where Registration No is literally 'nan' / empty
for df in (ext_products, ext_recs, df_audit):
    mask_nan = df.iloc[:, 0].astype(str).str.lower().isin(['nan', '', 'none'])
    if mask_nan.any():
        df.drop(df[mask_nan].index, inplace=True)

# ------------------------------------------------------------------
# 3. MASTER PRODUCTS TABLE
# ------------------------------------------------------------------
print("[3/7] Building master_products ...")
master_products = ext_products.rename(columns={
    'Registration No'         : 'registration_no',
    'Category'               : 'product_type',
    'Common Name'            : 'active_ingredient',
    'Trade Name'             : 'trade_name',
    'Registration Holder'    : 'registrant_holder',
    'Formulation'             : 'formulation',
    'Formulation Type'        : 'formulation_type',
    'Toxicity Class'         : 'toxicity_class',
    'PHI (days)'             : 'phi_days',
    'REI (hours)'            : 'rei_hours',
    'Registration Status'    : 'registration_status',
    'MoA Code'               : 'moa_code',
    'MoA Authority'          : 'moa_authority',
    'Mechanism'              : 'moa_description',
    'Target Site'            : 'target_site',
    'Resistance Risk'        : 'resistance_risk',
    'Rotation Partners'      : 'rotation_partners',
    'HHP Status'             : 'is_hhp',
    'Bangladesh Policy Action': 'policy_action',
    'Policy Risk Tier'       : 'policy_risk_tier',
    'EU / Global Status'    : 'eu_global_status',
})[
    ['registration_no', 'product_type', 'active_ingredient', 'trade_name',
     'registrant_holder', 'formulation', 'formulation_type', 'toxicity_class',
     'is_hhp', 'phi_days', 'rei_hours', 'registration_status', 'moa_code',
     'moa_authority', 'moa_description', 'target_site', 'resistance_risk',
     'rotation_partners', 'policy_action', 'policy_risk_tier', 'eu_global_status']
].copy()
master_products.drop_duplicates(subset='registration_no', keep='first', inplace=True)
print(f"   master_products: {len(master_products)} unique registrations")

# ------------------------------------------------------------------
# 4. MASTER RECOMMENDATIONS TABLE (normalized crop/pest/dosage rows)
# ------------------------------------------------------------------
print("[4/7] Building master_recs ...")
master_recs = ext_recs.rename(columns={
    'Registration No': 'registration_no',
    'Crop'           : 'crop',
    'Pest'           : 'pest',
    'Dosage Rate'    : 'dosage',
    'Origin'         : 'origin',
}).copy()
# Stable surrogate key
master_recs.insert(0, 'rec_id', range(1, len(master_recs) + 1))

# Carry PHI / REI / product_type / trade_name for app-level joins
phi_rei = master_products[
    ['registration_no', 'phi_days', 'rei_hours', 'product_type', 'trade_name']
]
master_recs = master_recs.merge(phi_rei, on='registration_no', how='left')
print(f"   master_recs: {len(master_recs)} normalized recommendation rows")

# ------------------------------------------------------------------
# 5. MoA REFERENCE AUTHORITY
# ------------------------------------------------------------------
print("[5/7] Building master_moa ...")
master_moa = ext_moa.rename(columns={
    'MoA Code'           : 'moa_code',
    'MoA Authority'      : 'moa_authority',
    'Group Code'         : 'group_code',
    'Mechanism of Action': 'moa_group_name',
    'Target Site'        : 'target_site',
    'Resistance Risk'    : 'resistance_risk',
    'Rotation Partners'  : 'rotation_partners',
}).drop_duplicates().copy()
print(f"   master_moa: {len(master_moa)} unique MoA groups")

# ------------------------------------------------------------------
# 6. REGULATORY & AUDIT OVERLAY (v2 MoA_Audit merged with Extract policy)
# ------------------------------------------------------------------
print("[6/7] Building master_regulatory ...")
# Audit side
audit_side = df_audit.rename(columns={
    'status'          : 'moa_audit_status',
    'policy_action'   : 'policy_action_v2',
    'policy_risk_tier': 'risk_tier_v2',
})[
    ['registration_no', 'moa_audit_status', 'policy_action_v2', 'risk_tier_v2']
].copy()

# Extract side (canonical)
ext_policy = master_products[
    ['registration_no', 'policy_action', 'policy_risk_tier']
].rename(columns={
    'policy_action'   : 'policy_action_ext',
    'policy_risk_tier': 'policy_risk_tier_ext',
}).copy()

# Outer merge on registration_no so we keep every audited or registered product
audit_merge = pd.merge(audit_side, ext_policy, on='registration_no', how='outer')

# Reconciliation: Extract policy overrides v2 audit fields (Extract is canonical / newer)
audit_merge['final_policy_action'] = (
    audit_merge['policy_action_ext'].fillna(audit_merge['policy_action_v2'])
)
audit_merge['final_risk_tier'] = (
    audit_merge['policy_risk_tier_ext'].fillna(audit_merge['risk_tier_v2'])
)

master_regulatory = audit_merge[
    ['registration_no', 'final_policy_action', 'final_risk_tier', 'moa_audit_status']
].copy()
master_regulatory.columns = [
    'registration_no', 'policy_action', 'risk_tier', 'moa_audit_status'
]
print(f"   master_regulatory: {len(master_regulatory)} rows (union of audit + registry)")

# ------------------------------------------------------------------
# 7. EXPORT TO EXCEL & SQLITE
# ------------------------------------------------------------------
print("[7/7] Writing outputs ...")
with pd.ExcelWriter(out_xlsx, engine='openpyxl') as writer:
    master_products.to_excel(writer, sheet_name='Products',           index=False)
    master_recs.to_excel(writer,    sheet_name='Recommendations',     index=False)
    master_moa.to_excel(writer,     sheet_name='MoA_Reference',       index=False)
    master_regulatory.to_excel(writer, sheet_name='Regulatory_Audit', index=False)

conn = sqlite3.connect(out_sqlite)
master_products.to_sql('Products',          conn, if_exists='replace', index=False)
master_recs.to_sql(    'Recommendations',    conn, if_exists='replace', index=False)
master_moa.to_sql(     'MoA_Reference',       conn, if_exists='replace', index=False)
master_regulatory.to_sql('Regulatory_Audit', conn, if_exists='replace', index=False)
conn.close()

# ------------------------------------------------------------------
# 8. SUMMARY
# ------------------------------------------------------------------
print("\n" + "=" * 60)
print("PesticideNext Master Database — build complete")
print("=" * 60)
print(f"  Products            : {len(master_products):>7,} rows")
print(f"  Recommendations     : {len(master_recs):>7,} rows")
print(f"  MoA_Reference       : {len(master_moa):>7,} rows")
print(f"  Regulatory_Audit    : {len(master_regulatory):>7,} rows")
print("-" * 60)
print(f"  Excel  : {out_xlsx}")
print(f"  SQLite : {out_sqlite}")
