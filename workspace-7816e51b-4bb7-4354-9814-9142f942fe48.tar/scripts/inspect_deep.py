"""Deep inspection: look at real headers (possibly offset) and sample rows."""
import pandas as pd

extract_path = '/home/z/my-project/upload/AgriChem_DAE_Pesticide_Registry_Extracted (1).xlsx'
schema_path = '/home/z/my-project/upload/AgriChem_Clean_Database_Schema_v2 (2).xlsx'

print("=" * 70)
print("SCHEMA v2 — MoA_Audit sheet, first 5 rows RAW (no header)")
print("=" * 70)
df = pd.read_excel(schema_path, sheet_name='MoA_Audit', header=None, nrows=5)
print(df.to_string())

print("\n" + "=" * 70)
print("SCHEMA v2 — Products sheet, first 5 rows RAW (no header)")
print("=" * 70)
df = pd.read_excel(schema_path, sheet_name='Products', header=None, nrows=5)
print(df.to_string())

print("\n" + "=" * 70)
print("EXTRACT — Products sheet, first 3 rows")
print("=" * 70)
df = pd.read_excel(extract_path, sheet_name='Products', nrows=3)
print(df.to_string())

print("\n" + "=" * 70)
print("EXTRACT — Recommendations sheet, first 3 rows")
print("=" * 70)
df = pd.read_excel(extract_path, sheet_name='Recommendations', nrows=3)
print(df.to_string())

print("\n" + "=" * 70)
print("EXTRACT — MoA_Groups sheet, first 3 rows")
print("=" * 70)
df = pd.read_excel(extract_path, sheet_name='MoA_Groups', nrows=3)
print(df.to_string())

print("\n" + "=" * 70)
print("EXTRACT — Product_MoA sheet, first 3 rows")
print("=" * 70)
df = pd.read_excel(extract_path, sheet_name='Product_MoA', nrows=3)
print(df.to_string())
