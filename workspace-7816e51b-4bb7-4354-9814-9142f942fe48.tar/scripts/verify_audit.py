"""Verify v2 MoA_Audit sheet reads correctly with header=4 + usecols='B:O'."""
import pandas as pd

schema_path = '/home/z/my-project/upload/AgriChem_Clean_Database_Schema_v2 (2).xlsx'

df = pd.read_excel(schema_path, sheet_name='MoA_Audit', header=4, usecols='B:O')
print("MoA_Audit shape:", df.shape)
print("Columns:", list(df.columns))
print("\nFirst 3 rows:")
print(df.head(3).to_string())

print("\nNull counts (first col):")
print(df.iloc[:, 0].isna().sum(), "NaN values in first column")

# Verify policy_action / policy_risk_tier values look real
if 'policy_action' in df.columns:
    print("\npolicy_action value counts:")
    print(df['policy_action'].value_counts(dropna=False).head(10))
if 'policy_risk_tier' in df.columns:
    print("\npolicy_risk_tier value counts:")
    print(df['policy_risk_tier'].value_counts(dropna=False).head(10))
if 'status' in df.columns:
    print("\nstatus value counts:")
    print(df['status'].value_counts(dropna=False).head(10))
